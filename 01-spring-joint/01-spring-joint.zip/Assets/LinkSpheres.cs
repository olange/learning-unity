﻿using UnityEngine;
using System.Collections;

public class LinkSpheres : MonoBehaviour {
	public Transform origin;
	public Transform end;
	
	LineRenderer link;

	void Start () {
		this.link = this.GetComponent<LineRenderer>();
	}
	
	void FixedUpdate () {
		link.SetPosition( 0, origin.position);
		link.SetPosition( 1, end.position);
	}
}